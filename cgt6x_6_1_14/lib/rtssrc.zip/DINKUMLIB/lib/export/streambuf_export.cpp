// EXPORTED FUNCTIONS
#include <streambuf>
_STD_BEGIN

template<class _Elem, class _Traits>
	streamsize basic_streambuf<_Elem, _Traits>::xsgetn(_Elem * _Ptr,
	streamsize _Count)
	{	// get _Count characters from stream
	int_type _Meta;
	streamsize _Size, _Copied;

	for (_Copied = 0; 0 < _Count; )
		if (0 < (_Size = _Gnavail()))
			{	// copy from read buffer
			if (_Count < _Size)
				_Size = _Count;
			_Traits::copy(_Ptr, gptr(), _Size);
			_Ptr += _Size;
			_Copied += _Size;
			_Count -= _Size;
			gbump((int)_Size);
			}
		else if (_Traits::eq_int_type(_Traits::eof(), _Meta = uflow()))
			break;	// end of file, quit
		else
			{	// get a single character
			*_Ptr++ = _Traits::to_char_type(_Meta);
			++_Copied;
			--_Count;
			}

	return (_Copied);
	}

template<class _Elem, class _Traits>
	streamsize basic_streambuf<_Elem, _Traits>::xsputn(const _Elem *_Ptr,
	streamsize _Count)
	{	// put _Count characters to stream
	streamsize _Size, _Copied;

	for (_Copied = 0; 0 < _Count; )
		if (0 < (_Size = _Pnavail()))
			{	// copy to write buffer
			if (_Count < _Size)
				_Size = _Count;
			_Traits::copy(pptr(), _Ptr, _Size);
			_Ptr += _Size;
			_Copied += _Size;
			_Count -= _Size;
			pbump((int)_Size);
			}
		else if (_Traits::eq_int_type(_Traits::eof(),
			overflow(_Traits::to_int_type(*_Ptr))))
			break;	// single character put failed, quit
		else
			{	// count character successfully put
			++_Ptr;
			++_Copied;
			--_Count;
			}

	return (_Copied);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
