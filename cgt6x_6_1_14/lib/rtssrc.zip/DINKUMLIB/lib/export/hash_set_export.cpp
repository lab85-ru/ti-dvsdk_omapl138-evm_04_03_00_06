// EXPORTED FUNCTIONS
#include <hash_set>
_STD_BEGIN

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_set<_Kty, _Tr, _Alloc>::hash_set(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct set from sequence, defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_set<_Kty, _Tr, _Alloc>::hash_set(_Iter _First, _Iter _Last,
		const key_compare& _Traits)
	: _Mybase(_Traits, allocator_type())
	{	// construct set from sequence, comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_set<_Kty, _Tr, _Alloc>::hash_set(_Iter _First, _Iter _Last,
		const key_compare& _Traits, const allocator_type& _Al)
	: _Mybase(_Traits, _Al)
	{	// construct set from sequence, comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_set<_Kty, hash<_Kty>, _Keyeq>::hash_set(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct set from sequence, defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_set<_Kty, hash<_Kty>, _Keyeq>::hash_set(_Iter _First, _Iter _Last,
		size_type)
	: _Mybase(key_compare(), allocator_type())
	{	// construct set from sequence, ignore initial size
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_set<_Kty, hash<_Kty>, _Keyeq>::hash_set(_Iter _First, _Iter _Last,
		size_type, const hasher& _Hasharg)
	: _Mybase(key_compare(_Hasharg), allocator_type())
	{	// construct set from sequence, comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_set<_Kty, hash<_Kty>, _Keyeq>::hash_set(_Iter _First, _Iter _Last,
		size_type, const hasher& _Hasharg, const _Keyeq& _Keyeqarg)
	: _Mybase(key_compare(_Hasharg, _Keyeqarg), allocator_type())
	{	// construct set from sequence, comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_multiset<_Kty, _Tr, _Alloc>::hash_multiset(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct from sequence, defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_multiset<_Kty, _Tr, _Alloc>::hash_multiset(_Iter _First, _Iter _Last,
		const key_compare& _Traits)
	: _Mybase(_Traits, allocator_type())
	{	// construct from sequence, comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	hash_multiset<_Kty, _Tr, _Alloc>::hash_multiset(_Iter _First, _Iter _Last,
		const key_compare& _Traits, const allocator_type& _Al)
	: _Mybase(_Traits, _Al)
	{	// construct from sequence, comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Tr, class _Alloc>
	template<class _Iter>
	void hash_multiset<_Kty, _Tr, _Alloc>::insert(_Iter _First, _Iter _Last)
	{	// insert [_First, _Last), arbitrary iterators

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("hash_multiset insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	for (; _First != _Last; ++_First)
		insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_multiset<_Kty, hash<_Kty>, _Keyeq>::hash_multiset(_Iter _First, _Iter _Last)
	: _Mybase(key_compare(), allocator_type())
	{	// construct set from sequence, defaults
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_multiset<_Kty, hash<_Kty>, _Keyeq>::hash_multiset(_Iter _First, _Iter _Last,
		size_type)
	: _Mybase(key_compare(), allocator_type())
	{	// construct set from sequence, defaults, ignore initial size
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_multiset<_Kty, hash<_Kty>, _Keyeq>::hash_multiset(_Iter _First, _Iter _Last,
		size_type, const hasher& _Hasharg)
	: _Mybase(key_compare(_Hasharg), allocator_type())
	{	// construct set from sequence, comparator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	hash_multiset<_Kty, hash<_Kty>, _Keyeq>::hash_multiset(_Iter _First, _Iter _Last,
		size_type, const hasher& _Hasharg, const _Keyeq& _Keyeqarg)
	: _Mybase(key_compare(_Hasharg, _Keyeqarg), allocator_type())
	{	// construct set from sequence, comparator, and allocator
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last; ++_First)
		this->insert(*_First);
	}

template<class _Kty, class _Keyeq>
	template<class _Iter>
	void hash_multiset<_Kty, hash<_Kty>, _Keyeq>::insert(_Iter _First, _Iter _Last)
	{	// insert [_First, _Last), arbitrary iterators

 #if _HAS_ITERATOR_DEBUGGING
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("hash_multiset insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	for (; _First != _Last; ++_First)
		insert(*_First);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
