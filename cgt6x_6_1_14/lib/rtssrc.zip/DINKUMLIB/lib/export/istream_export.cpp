// EXPORTED FUNCTIONS
#include <istream>
_STD_BEGIN

template<class _Elem, class _Traits>
	bool basic_istream<_Elem, _Traits>::_Ipfx(bool _Noskip)
	{	// test stream state and skip whitespace as needed
	if (ios_base::good())
		{	// state okay, flush tied stream and skip whitespace
		if (_Myios::tie() != 0)
			_Myios::tie()->flush();

		if (!_Noskip && ios_base::flags() & ios_base::skipws)
			{	// skip whitespace
			const _Ctype& _Ctype_fac = use_facet< _Ctype >(ios_base::getloc());

			_TRY_IO_BEGIN
			int_type _Meta = _Myios::rdbuf()->sgetc();

			for (; ; _Meta = _Myios::rdbuf()->snextc())
				if (_Traits::eq_int_type(_Traits::eof(), _Meta))
					{	// end of file, quit
					_Myios::setstate(ios_base::eofbit);
					break;
					}
				else if (!_Ctype_fac.is(_Ctype::space,
					_Traits::to_char_type(_Meta)))
					break;	// not whitespace, quit
			_CATCH_IO_END
			}

		if (ios_base::good())
			return (true);
		}
	_Myios::setstate(ios_base::failbit);
	return (false);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(_Bool& _Val)
	{	// extract a boolean
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(short& _Val)
	{	// extract a short
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		long _Tmp = 0;
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Tmp);
		_CATCH_IO_END

		if (_State & ios_base::failbit
			|| _Tmp < SHRT_MIN || SHRT_MAX < _Tmp)
			_State |= ios_base::failbit;
		else
			_Val = (short)_Tmp;
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(unsigned short& _Val)
	{	// extract an unsigned short
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(int& _Val)
	{	// extract an int
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		long _Tmp = 0;
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Tmp);
		_CATCH_IO_END

		if (_State & ios_base::failbit
			|| _Tmp < INT_MIN || INT_MAX < _Tmp)
			_State |= ios_base::failbit;
		else
			_Val = _Tmp;
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(unsigned int& _Val)
	{	// extract an unsigned int
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);
	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(long& _Val)
	{	// extract a long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());
		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(unsigned long& _Val)
	{	// extract an unsigned long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(_LONGLONG& _Val)
	{	// extract a long long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(_ULONGLONG& _Val)
	{	// extract an  unsigned long long
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);
	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(float& _Val)
	{	// extract a float
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(double& _Val)
	{	// extract a double
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);
	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(long double& _Val)
	{	// extract a long double
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());
		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(void *& _Val)
	{	// extract a void pointer
	ios_base::iostate _State = ios_base::goodbit;
	const sentry _Ok(*this);

	if (_Ok)
		{	// state okay, use facet to extract
		const _Nget& _Nget_fac = use_facet< _Nget >(ios_base::getloc());

		_TRY_IO_BEGIN
		_Nget_fac.get(_Iter(_Myios::rdbuf()), _Iter(0),
			*this, _State, _Val);
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::operator>>(_Mysb *_Strbuf)
	{	// extract until end-of-file into a stream buffer
	ios_base::iostate _State = ios_base::goodbit;
	bool _Copied = false;
	const sentry _Ok(*this);

	if (_Ok && _Strbuf != 0)
		{	// state okay, extract characters
		_TRY_IO_BEGIN
		int_type _Meta = _Myios::rdbuf()->sgetc();

		for (; ; _Meta = _Myios::rdbuf()->snextc())
			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else
				{	// got a character, insert it into buffer
				_TRY_BEGIN
					if (_Traits::eq_int_type(_Traits::eof(),
						_Strbuf->sputc(_Traits::to_char_type(_Meta))))
						break;
				_CATCH_ALL
					break;
				_CATCH_END
				_Copied = true;
				}
		_CATCH_IO_END
		}

	_Myios::setstate(!_Copied ? _State | ios_base::failbit : _State);
	return (*this);
	}

template<class _Elem, class _Traits>
	typename basic_istream<_Elem, _Traits>::int_type basic_istream<_Elem, _Traits>::get()
	{	// extract a metacharacter
	int_type _Meta = 0;
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (!_Ok)
		_Meta = _Traits::eof();	// state not okay, return EOF
	else
		{	// state okay, extract a character
		_TRY_IO_BEGIN
		_Meta = _Myios::rdbuf()->sbumpc();

		if (_Traits::eq_int_type(_Traits::eof(), _Meta))
			_State |= ios_base::eofbit | ios_base::failbit;	// end of file
		else
			++_Chcount;	// got a character, count it
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (_Meta);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::get(_Elem *_Str,
	streamsize _Count, _Elem _Delim)
	{	// get up to _Count characters into NTCS, stop before _Delim
	_DEBUG_POINTER(_Str);
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok && 0 < _Count)
		{	// state okay, extract characters
		_TRY_IO_BEGIN
		int_type _Meta = _Myios::rdbuf()->sgetc();

		for (; 0 < --_Count; _Meta = _Myios::rdbuf()->snextc())
			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else if (_Traits::to_char_type(_Meta) == _Delim)
				break;	// got a delimiter, quit
			else
				{	// got a character, add it to string
				*_Str++ = _Traits::to_char_type(_Meta);
				++_Chcount;
				}
		_CATCH_IO_END
		}

	_Myios::setstate(_Chcount == 0
		? _State | ios_base::failbit : _State);
	*_Str = _Elem();	// add terminating null character
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::get(_Elem& _Ch)
	{	// get a character
	int_type _Meta = get();
	if (!_Traits::eq_int_type(_Traits::eof(), _Meta))
		_Ch = _Traits::to_char_type(_Meta);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::get(_Mysb& _Strbuf, _Elem _Delim)
	{	// extract up to delimiter and insert into stream buffer
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok)
		{	// state okay, use facet to extract
		_TRY_IO_BEGIN
		int_type _Meta = _Myios::rdbuf()->sgetc();

		for (; ; _Meta = _Myios::rdbuf()->snextc())
			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else
				{	// got a character, insert it into stream buffer
				_TRY_BEGIN
					_Elem _Ch = _Traits::to_char_type(_Meta);
					if (_Ch == _Delim
						|| _Traits::eq_int_type(_Traits::eof(),
							_Strbuf.sputc(_Ch)))
						break;
				_CATCH_ALL
					break;
				_CATCH_END
				++_Chcount;
				}
		_CATCH_IO_END
		}

	if (_Chcount == 0)
		_State |= ios_base::failbit;
	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::getline(_Elem *_Str,
	streamsize _Count, _Elem _Delim)
	{	// get up to _Count characters into NTCS, discard _Delim
	_DEBUG_POINTER(_Str);
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok && 0 < _Count)
		{	// state okay, use facet to extract
		int_type _Metadelim = _Traits::to_int_type(_Delim);

		_TRY_IO_BEGIN
		int_type _Meta = _Myios::rdbuf()->sgetc();

		for (; ; _Meta = _Myios::rdbuf()->snextc())
			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else if (_Meta == _Metadelim)
				{	// got a delimiter, discard it and quit
				++_Chcount;
				_Myios::rdbuf()->sbumpc();
				break;
				}
			else if (--_Count <= 0)
				{	// buffer full, quit
				_State |= ios_base::failbit;
				break;
				}
			else
				{	// got a character, add it to string
				++_Chcount;
				*_Str++ = _Traits::to_char_type(_Meta);
				}
		_CATCH_IO_END
		}

	*_Str = _Elem();	// add terminating null character
	_Myios::setstate(_Chcount == 0 ? _State | ios_base::failbit : _State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::ignore(streamsize _Count,
	int_type _Metadelim)
	{	// ignore up to _Count characters, discarding delimiter
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok && 0 < _Count)
		{	// state okay, use facet to extract
		_TRY_IO_BEGIN
		for (; ; )
			{	// get a metacharacter if more room in buffer
			int_type _Meta;
			if (_Count != INT_MAX && --_Count < 0)
				break;	// buffer full, quit
			else if (_Traits::eq_int_type(_Traits::eof(),
				_Meta = _Myios::rdbuf()->sbumpc()))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else
				{	// got a character, count it
				++_Chcount;
				if (_Meta == _Metadelim)
					break;	// got a delimiter, quit
				}
			}
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::read(_Elem *_Str, streamsize _Count)
	{	// read up to _Count characters into buffer
	_DEBUG_POINTER(_Str);
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok)
		{	// state okay, use facet to extract
		_TRY_IO_BEGIN
		const streamsize _Num = _Myios::rdbuf()->sgetn(_Str, _Count);
		_Chcount += _Num;
		if (_Num != _Count)
			_State |= ios_base::eofbit | ios_base::failbit;	// short read
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	streamsize basic_istream<_Elem, _Traits>::readsome(_Elem *_Str,
	streamsize _Count)
	{	// read up to _Count characters into buffer, without blocking
	_DEBUG_POINTER(_Str);
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);
	streamsize _Num;

	if (!_Ok)
		_State |= ios_base::failbit;	// no buffer, fail
	else if ((_Num = _Myios::rdbuf()->in_avail()) < 0)
		_State |= ios_base::eofbit;	// no characters available
	else if (0 < _Num)
		read(_Str, _Num < _Count ? _Num : _Count);	// read available

	_Myios::setstate(_State);
	return (gcount());
	}

template<class _Elem, class _Traits>
	typename basic_istream<_Elem, _Traits>::int_type basic_istream<_Elem, _Traits>::peek()
	{	// return next character, unconsumed
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	int_type _Meta = 0;
	const sentry _Ok(*this, true);

	if (!_Ok)
		_Meta = _Traits::eof();	// state not okay, return EOF
	else
		{	// state okay, read a character
		_TRY_IO_BEGIN
		if (_Traits::eq_int_type(_Traits::eof(),
			_Meta = _Myios::rdbuf()->sgetc()))
			_State |= ios_base::eofbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (_Meta);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::putback(_Elem _Ch)
	{	// put back a character
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok)
		{	// state okay, put character back
		_TRY_IO_BEGIN
		if (_Traits::eq_int_type(_Traits::eof(),
			_Myios::rdbuf()->sputbackc(_Ch)))
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_istream<_Elem, _Traits>& basic_istream<_Elem, _Traits>::unget()
	{	// put back last read character
	ios_base::iostate _State = ios_base::goodbit;
	_Chcount = 0;
	const sentry _Ok(*this, true);

	if (_Ok)
		{	// state okay, use facet to extract
		_TRY_IO_BEGIN
		if (_Traits::eq_int_type(_Traits::eof(),
			_Myios::rdbuf()->sungetc()))
			_State |= ios_base::badbit;
		_CATCH_IO_END
		}

	_Myios::setstate(_State);
	return (*this);
	}

template<class _Elem, class _Traits>
	int basic_istream<_Elem, _Traits>::sync()
	{	// synchronize with input source
	ios_base::iostate _State = ios_base::goodbit;
	int _Ans;

	if (_Myios::rdbuf() == 0)
		_Ans = -1;	// no buffer, fail
	else if (_Myios::rdbuf()->pubsync() == -1)
		{	// stream buffer sync failed, fail
		_State |= ios_base::badbit;
		_Ans = -1;
		}
	else
		_Ans = 0;	// success

	_Myios::setstate(_State);
	return (_Ans);
	}

template<class _Elem,
	class _Traits>
	basic_istream<_Elem, _Traits>& operator>>(
		basic_istream<_Elem, _Traits>& _Istr, _Elem *_Str)
	{	// extract NTBS
	_DEBUG_POINTER(_Str);
	typedef basic_istream<_Elem, _Traits> _Myis;
	typedef ctype<_Elem> _Ctype;
	ios_base::iostate _State = ios_base::goodbit;
	_Elem *_Str0 = _Str;
	const typename _Myis::sentry _Ok(_Istr);

	if (_Ok)
		{	// state okay, extract characters
		const _Ctype& _Ctype_fac = use_facet< _Ctype >(_Istr.getloc());

		_TRY_IO_BEGIN
		streamsize _Count = 0 < _Istr.width() ? _Istr.width() : INT_MAX;
		typename _Myis::int_type _Meta = _Istr.rdbuf()->sgetc();
		_Elem _Ch;
		for (; 0 < --_Count; _Meta = _Istr.rdbuf()->snextc())
			if (_Traits::eq_int_type(_Traits::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else if (_Ctype_fac.is(_Ctype::space,
				_Ch = _Traits::to_char_type(_Meta))
					|| _Ch == _Elem())
				break;	// whitespace or nul, quit
			else
				*_Str++ = _Traits::to_char_type(_Meta);	// add it to string
		_CATCH_IO_(_Istr)
		}

	*_Str = _Elem();	// add terminating null character
	_Istr.width(0);
	_Istr.setstate(_Str == _Str0 ? _State | ios_base::failbit : _State);
	return (_Istr);
	}

template<class _Elem,
	class _Traits>
	basic_istream<_Elem, _Traits>& operator>>(
		basic_istream<_Elem, _Traits>& _Istr, _Elem& _Ch)
	{	// extract a character
	typedef basic_istream<_Elem, _Traits> _Myis;
	typename _Myis::int_type _Meta;
	ios_base::iostate _State = ios_base::goodbit;
	const typename _Myis::sentry _Ok(_Istr);

	if (_Ok)
		{	// state okay, extract characters
		_TRY_IO_BEGIN
		_Meta = _Istr.rdbuf()->sbumpc();
		if (_Traits::eq_int_type(_Traits::eof(), _Meta))
			_State |= ios_base::eofbit | ios_base::failbit;	// end of file
		else
			_Ch = _Traits::to_char_type(_Meta);	// got a character
		_CATCH_IO_(_Istr)
		}

	_Istr.setstate(_State);
	return (_Istr);
	}

template<class _Elem,
	class _Traits>
	basic_istream<_Elem, _Traits>&
		ws(basic_istream<_Elem, _Traits>& _Istr)
	{	// consume whitespace
	typedef basic_istream<_Elem, _Traits> _Myis;
	typedef ctype<_Elem> _Ctype;

	if (!_Istr.eof())
		{	// not at eof, okay to construct sentry and skip
		ios_base::iostate _State = ios_base::goodbit;
		const typename _Myis::sentry _Ok(_Istr, true);

		if (_Ok)
			{	// state okay, extract characters
			const _Ctype& _Ctype_fac = use_facet< _Ctype >(_Istr.getloc());

			_TRY_IO_BEGIN
			for (typename _Traits::int_type _Meta = _Istr.rdbuf()->sgetc(); ;
				_Meta = _Istr.rdbuf()->snextc())
				if (_Traits::eq_int_type(_Traits::eof(), _Meta))
					{	// end of file, quit
					_State |= ios_base::eofbit;
					break;
					}
				else if (!_Ctype_fac.is(_Ctype::space,
					_Traits::to_char_type(_Meta)))
					break;	// not whitespace, quit
			_CATCH_IO_(_Istr)
			}

		_Istr.setstate(_State);
		}
	return (_Istr);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
