// iomanip.h standard header
#ifndef _IOMANIP_H_
#define _IOMANIP_H_
#include <iomanip>

 #if _HAS_NAMESPACE
using namespace std;
 #endif /* _HAS_NAMESPACE */

#endif /* _IOMANIP_ */

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
