// delaop3 -- operator delete[](void *, void *)
#include <new>

void operator delete[](void *, void *) _THROW0()
	{	// do nothing if placement new fails
	}

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
