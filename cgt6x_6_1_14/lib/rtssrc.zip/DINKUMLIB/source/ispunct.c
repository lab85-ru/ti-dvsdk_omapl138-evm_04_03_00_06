/* ispunct function */
#if defined(__TI_COMPILER_VERSION__)
#undef _INLINE
#endif /* defined(__TI_COMPILER_VERSION__) */
#include <ctype.h>
_STD_BEGIN

int (ispunct)(int c)
	{	/* test for punctuation character */
	return (_Getchrtype(c) & _PU);
	}
_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
