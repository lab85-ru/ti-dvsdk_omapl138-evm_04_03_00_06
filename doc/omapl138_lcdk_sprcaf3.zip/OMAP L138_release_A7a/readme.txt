OMAP L138 and C6748 files are idenical except one uses OMAP L138 on the board and the other 
uses TMS320C6748. Therefore the bom's are different.