#!/bin/sh

TSLIB_TSDEVICE=/dev/input/touchscreen0

export TSLIB_TSDEVICE

