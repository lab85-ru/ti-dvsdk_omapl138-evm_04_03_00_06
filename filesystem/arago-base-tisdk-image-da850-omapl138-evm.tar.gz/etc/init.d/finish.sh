#!/bin/sh

if ! test -e /etc/.configured; then
	> /etc/.configured
fi

