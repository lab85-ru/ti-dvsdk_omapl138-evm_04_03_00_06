
This folder contains NAND flash writer for burning boot image on NAND flash.

The flash writer is written for NAND Flash on DA830 DSK board + UI board
available from Spectrum digital.

The current flash writer works on NAND flash populated in EMIF CS2 region.

To use the flash writer for another EMIF CS region, change the AEMIF memory 
segment origin in linker.cmd file in the top directory.

To add support for a new nand chip add the chip details to the 
DEVICE_NAND_CHIP_infoTable[] table.

The nand flash writer supports 4-bit ECC only.

