/*
 * Copyright (C) 2008 Texas Instruments, Inc <www.ti.com>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

// C standard I/O library
#include "stdio.h"
#include "string.h"

// General type include
#include "tistdtypes.h"

// Device specific CSL
#include "device.h"

// This module's header file 
#include "nandwriter.h"

// NAND driver include
#include "nand.h"
#include "device_nand.h"

// Misc. utility function include
#include "debug.h"
#include "util.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

static Uint32 nandwriter(void);
static Uint32 LOCAL_writeHeaderAndData(NAND_InfoHandle hNandInfo, NANDWRITER_Boot *nandBoot, Uint8 *srcBuf);


/************************************************************
* Global Variable Definitions
************************************************************/
int write_header = 0;
int dspais = 0;
int armubl = 0;
int uboot = 0;

//#pragma DATA_SECTION(DDRStart,".ddrram");
//VUint32 __FAR__ DDRStart;

#pragma DATA_SECTION(NANDStart,".aemif_mem");
VUint32 __FAR__ NANDStart;

// Global variables for page buffers 
static Uint8* gNandTx;
static Uint8* gNandRx;

/************************************************************
* Global Function Definitions                               *
************************************************************/
#define JTAG_ID_BASE    0x01c14018
#define CHIPREV_ID_BASE 0x01c14024
#define DA850_PART_NUM  0xb7d1
#define DA830_PART_NUM  0xb7df

/*
 * Get Device Part No. from JTAG ID register
 */
static Uint16 davinci_get_part_no(void)
{
        Uint32 dev_id, part_no;

        dev_id = *(unsigned int*) JTAG_ID_BASE;

        part_no = ((dev_id >> 12) & 0xffff);

        return part_no;
}


void main( void )
{
  int status;

  // Init memory alloc pointer
  UTIL_setCurrMemPtr(0);

#if 0
  // System init
  if (DEVICE_init() !=E_PASS)
  {
    exit();
  }
#endif

  // Execute the NAND flashing
  status = nandwriter();

  if (status != E_PASS)
  {
    DEBUG_printString("\n\nNAND flashing failed!\r\n");
  }
  else
  {
    DEBUG_printString( "\n\nNAND boot preparation was successful!\r\n" );
  }
}


/************************************************************
* Local Function Definitions                                *
************************************************************/

static Uint32 nandwriter()
{
  Uint32 numPages;

  NANDWRITER_Boot  gNandBoot;
  NAND_InfoHandle  hNandInfo;

  FILE  *fPtr;
  Uint8  *ptr;
  Int32  fileSize = 0,allocSize = 0;
  Int8  fileName[256], itype[20];
  Int32 i=0, armboot = 0;

  DEBUG_printString("Starting DA8xx_NANDWriter.\r\n");

  /* read the chip type you are on. */
  if (davinci_get_part_no() == DA850_PART_NUM ||
  	  davinci_get_part_no() == DA830_PART_NUM) {
    printf("DA8XX/OMAP-L1XX part detected. ");
    if (*(unsigned int*)(CHIPREV_ID_BASE) & (1 << 4)) {
      armboot = 1;
      printf("Its an ARM boot device\n"
        "\tYou require two images to boot this device\n"
        "\t1) ARM UBL in AIS file format.\n"
        "\t2) U-Boot image in raw binary format\n");
    } else {
        printf("Its a DSP  boot device\n"
            "\tYou require three images to boot\n"
            "\t1) DSP UBL in AIS file format.\n"
            "\t2) ARM UBL in raw binary format.\n"
            "\t3) U-Boot image in raw binary format\n");
    }

    printf("To generate the AIS format file, you need to run"
        " the ARM/DSP .out (COFF) file generated from"
        " CCS build through the AISGen tool.\n");
  }

  // Initialize NAND Flash
  hNandInfo = NAND_open((Uint32)&NANDStart);
  
  if (hNandInfo == NULL)
  {
    DEBUG_printString( "\tERROR: NAND Initialization failed.\r\n" );
    return E_FAIL;
  }

#ifdef __CCSv4_BUILD__  

  	// Read the file from host
  	fPtr = fopen("C:\\aisname.dat", "rb");
  	if(fPtr == NULL)
  	{
		DEBUG_printString("\tERROR: File C:\\aisname.dat open failed.\n"
      		"Please create a file by this name containing the path to the AIS binary to be flashed\n");
		return E_FAIL;
  	}
  	fscanf(fPtr, "%s", fileName);
  	DEBUG_printString("Opening file %s to write to the NAND\n", fileName);
  	fclose(fPtr);  

	dspais = 1;	/* Always burn DSP AIS image only with CCSv4 */

#else
    if(armboot)
        printf("Enter the image type (one of \"armais\" \"uboot\" \"other\")\n");
     else
        printf("Enter the image type (one of \"dspais\" \"armubl\" \"uboot\" \"other\")\n");
	scanf("%s", itype);
    if(!strcmp(itype, "dspais") || (armboot && !strcmp(itype, "armais"))) {
		dspais = 1;
    } else if(!armboot && !strcmp(itype, "armubl")) {
		armubl = 1;
		write_header = 1;
	} else if(!strcmp(itype, "uboot")) {
		uboot = 1;
		write_header = 1;
	}
  	// Read the file from host
	printf("Enter the file Name\n");
	scanf("%s", fileName);
	fflush(stdin);
#endif
	
  if (strcmp(fileName,"none") != 0)
  {
  	// Open an File from the hard drive
  	fPtr = fopen(fileName, "rb");
  	if(fPtr == NULL)
  	{
      DEBUG_printString("\tERROR: File ");
      DEBUG_printString(fileName);
      DEBUG_printString(" open failed.\r\n");
      return E_FAIL;
    }

    // Read file size
    fseek(fPtr,0,SEEK_END);
    fileSize = ftell(fPtr);

    if(fileSize == 0)
    {
      DEBUG_printString("\tERROR: File read failed.. Closing program.\r\n");
      fclose (fPtr);
      return E_FAIL;
    }

    numPages = 0;
    while ( (numPages * hNandInfo->dataBytesPerPage)  < fileSize )
    {
      numPages++;
    }

    //We want to allocate an even number of pages.
    allocSize = numPages * hNandInfo->dataBytesPerPage;

    // Setup pointer in RAM
    ptr = (Uint8 *) UTIL_allocMem(allocSize);
	if(ptr == NULL) {
		DEBUG_printString("\tERROR: Unable to allocate memory sized ");
		DEBUG_printHexInt(allocSize);
		DEBUG_printString(" bytes for file read\n");
		return E_FAIL;
	}

    for (i=0; i<allocSize; i++)
      ptr[i]=0x00;

    fseek(fPtr,0,SEEK_SET);

    if (fileSize != fread(ptr, 1, fileSize, fPtr))
    {
      DEBUG_printString("\tWARNING: File Size mismatch.\r\n");
    }

    fclose (fPtr);

	gNandBoot.page        = 0;
	gNandBoot.numPage     = numPages;

	if (dspais) {
		gNandBoot.magicNum    = UBL_MAGIC_SAFE;
		gNandBoot.block       = DEVICE_NAND_RBL_SEARCH_START_BLOCK;
		gNandBoot.entryPoint  = 0x0100;       
		gNandBoot.ldAddress   = 0;            
	} else if (armubl == 1) {
		gNandBoot.magicNum    = UBL_MAGIC_BIN_IMG;
		gNandBoot.block       = DEVICE_NAND_ARM_UBL_SEARCH_START_BLOCK;
		gNandBoot.entryPoint  = 0x80000000;       
		gNandBoot.ldAddress   = 0x80000000;   
	} else if (uboot == 1) {
		gNandBoot.magicNum    = UBL_MAGIC_BIN_IMG;
		gNandBoot.block       = (armboot ? 
				DEVICE_ARMBOOT_NAND_UBOOT_SEARCH_START_BLOCK :
				DEVICE_DSPBOOT_NAND_UBOOT_SEARCH_START_BLOCK);
		gNandBoot.entryPoint  = 0xc1080000;      
		gNandBoot.ldAddress   = 0xc1080000;
	}

    if (LOCAL_writeHeaderAndData(hNandInfo,&gNandBoot,ptr) != E_PASS)
    {
		printf("\tERROR: Write failed.\r\n");
		return E_FAIL;
    }
  }
  
  return E_PASS;
}

// Generic function to write a UBL or Application header and the associated data
static Uint32 LOCAL_writeHeaderAndData(NAND_InfoHandle hNandInfo, NANDWRITER_Boot *nandBoot, Uint8 *srcBuf)
 {
  Uint32    endBlockNum = NANDWRITER_END_APP_BLOCK_NUM;
  Uint32    *headerPtr;
  Uint32    blockNum;
  Uint32    count;
  Uint32    countMask;
  Uint32    numBlks;
  Uint32    pageNum;
  Uint32    i;
  Uint8     *dataPtr;


  gNandTx = (Uint8 *) UTIL_allocMem(NAND_MAX_PAGE_SIZE);
  gNandRx = (Uint8 *) UTIL_allocMem(NAND_MAX_PAGE_SIZE);

  for (i=0; i<NAND_MAX_PAGE_SIZE; i++)  
  {
    gNandTx[i]=0xff;
    gNandRx[i]=0xff;
  }  
  
  // Get total number of blocks needed
  numBlks = 0;
  while ( (numBlks * hNandInfo->pagesPerBlock)  < (nandBoot->numPage + 1) )
  {
    numBlks++;
  }
  DEBUG_printString("Number of blocks needed for data: ");
  DEBUG_printHexInt(numBlks);
  DEBUG_printString("\r\n");

  // Check whether writing UBL or APP (based on destination block)
  blockNum = nandBoot->block;

NAND_WRITE_RETRY:
  if (blockNum > endBlockNum)
  {
	DEBUG_printString("Size out of range. Cannot write upto block number ");
	DEBUG_printHexInt(blockNum);
	DEBUG_printString("\n"); 	
    return E_FAIL;
  }
  DEBUG_printString("Attempting to start write in block number ");
  DEBUG_printHexInt(blockNum);
  DEBUG_printString(".\r\n");

  // Unprotect all needed blocks of the Flash 
  if (NAND_unProtectBlocks(hNandInfo,blockNum,numBlks) != E_PASS)
  {
    blockNum++;
    DEBUG_printString("Unprotect failed.\r\n");
    goto NAND_WRITE_RETRY;
  }
  
  // Setup header to be written
  headerPtr = (Uint32 *) gNandTx;
  headerPtr[0] = nandBoot->magicNum;          //Magic Number
  headerPtr[1] = nandBoot->entryPoint;        //Entry Point
  headerPtr[2] = nandBoot->numPage;           //Number of Pages
  headerPtr[3] = blockNum;                    //Starting Block Number 
  headerPtr[4] = 1;                           //Starting Page Number - always start data in page 1 (this header goes in page 0)

  if ( (blockNum>=DEVICE_NAND_RBL_SEARCH_START_BLOCK) &&  (blockNum <= DEVICE_NAND_SEARCH_END_BLOCK) && dspais)
  {
    headerPtr[5] = 0;
  }
  else if ( (blockNum>=DEVICE_NAND_ARM_UBL_SEARCH_START_BLOCK) &&  (blockNum<=DEVICE_NAND_SEARCH_END_BLOCK))
  {
    headerPtr[5] = nandBoot->ldAddress;         //nandBoot->ldAddress;
  }
  else
  {
    // Block number is out of range
    return E_FAIL; 
  }
  pageNum = 0;
    
  // Erase the block where the header goes and the data starts
  if (NAND_eraseBlocks(hNandInfo,blockNum,numBlks) != E_PASS)
  {
    blockNum++;
    DEBUG_printString("Erase failed\n");
    goto NAND_WRITE_RETRY;
  }

  if (write_header) {
	// Start writing in page 0 of current block (data will be in page 1)
	count = 0;
  	if (NAND_writePage(hNandInfo, blockNum, pageNum, gNandTx) != E_PASS)
  	{
    	blockNum++;
    	DEBUG_printString("Write failed\n");
    	NAND_reset(hNandInfo);
    	goto NAND_WRITE_RETRY;
  	}
    
  	UTIL_waitLoop(200);

  	// Verify the page just written
  	if (NAND_verifyPage(hNandInfo, blockNum, pageNum, gNandTx, gNandRx) != E_PASS)
  	{
    	DEBUG_printString("Verify failed. Attempting to clear page\n");
    	NAND_reset(hNandInfo);
    	NAND_eraseBlocks(hNandInfo,blockNum,numBlks);
    
    	blockNum++;
    	NAND_reset(hNandInfo);

    	goto NAND_WRITE_RETRY;
  	}
	count++;
  } /* write_header */

  // The following assumes power of 2 pagesPerBlock -  *should* always be valid 
  countMask = (Uint32) hNandInfo->pagesPerBlock - 1;
  dataPtr = srcBuf;

  do
  {
    DEBUG_printString("Writing image data to Block ");
    DEBUG_printHexInt(blockNum);
    DEBUG_printString(", Page ");
    DEBUG_printHexInt(count & countMask);
    DEBUG_printString("\r\n");

    // Write the UBL or APP data on a per page basis
    if (NAND_writePage(hNandInfo, blockNum,  (count & countMask), dataPtr) != E_PASS)
    {
      blockNum++;
      DEBUG_printString("Write failed\n");
      goto NAND_WRITE_RETRY;
    }
    
    UTIL_waitLoop(200);
    
    // Verify the page just written
    if (NAND_verifyPage(hNandInfo, blockNum, (count & countMask), dataPtr, gNandRx) != E_PASS)
    {
      DEBUG_printString("Verify failed. Attempting to clear page\n");
      NAND_reset(hNandInfo);
      NAND_eraseBlocks(hNandInfo,blockNum,numBlks);
      blockNum++;
      goto NAND_WRITE_RETRY;
    }
    
    count++;
    dataPtr +=  hNandInfo->dataBytesPerPage;
    if (!(count & countMask))
    {
      do
      {
        blockNum++;
      }
      while (NAND_badBlockCheck(hNandInfo,blockNum) != E_PASS);
    }
  } while (count <= nandBoot->numPage);

  NAND_protectBlocks(hNandInfo);

  return E_PASS;
}


/***********************************************************
* End file                                                 
************************************************************/

/* --------------------------------------------------------------------------
  HISTORY
    v1.00 - DJA - 24-Mar-2008
      Initial release
-------------------------------------------------------------------------- */

