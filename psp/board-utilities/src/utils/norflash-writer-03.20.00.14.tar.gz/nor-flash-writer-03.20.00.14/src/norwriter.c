/*
 * TI Booting and Flashing Utilities
 *
 * Main function for flashing the NOR device on the DM644x EVM.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

// C standard I/O library
#include "stdio.h"
#include "string.h"

// General type include
#include "tistdtypes.h"

// Device specific CSL
#include "device.h"

// This module's header file 
#include "norwriter.h"

// NOR driver include
#include "nor.h"

// Misc. utility function include
#include "util.h"

// Debug module
#include "debug.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/

#pragma DATA_SECTION(NORStart,".aemif_mem");
VUint32 __FAR__ NORStart;

extern __FAR__ Uint32 DDRStart;


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

static Uint32 norwriter(void);


/************************************************************
* Local Variable Definitions                                *
\***********************************************************/


/************************************************************
* Global Variable Definitions
************************************************************/


/************************************************************
* Global Function Definitions                               *
************************************************************/

void main( void )
{
    Uint32 status;

	// Init memory alloc pointer to start of DDR heap
	UTIL_setCurrMemPtr(0);

#if 0
  // System init
  if (DEVICE_init() !=E_PASS)
  {
    exit();
  }
#endif
	
	// Execute the NOR flashing
  status = norwriter();

  if (status != E_PASS)
  {
    printf( "\tNOR flashing failed!\r\n");
  }
  else
  {
    printf( "\tNOR boot preparation was successful!\r\n" );
  }
}

#define JTAG_ID_BASE    0x01c14018
#define CHIPREV_ID_BASE 0x01c14024
#define DA850_PART_NUM  0xb7d1
#define DA830_PART_NUM  0xb7df

/*
 * Get Device Part No. from JTAG ID register
 */
static Uint16 davinci_get_part_no(void)
{
        Uint32 dev_id, part_no;

        dev_id = *(unsigned int*) JTAG_ID_BASE;

        part_no = ((dev_id >> 12) & 0xffff);

        return part_no;
}

/************************************************************
* Local Function Definitions                                *
************************************************************/

static Uint32 norwriter()
{
  NOR_InfoHandle hNorInfo;
  NORWRITER_Boot *norBoot;
  FILE	*fPtr;
  Uint8	*filePtr, *tmp;
  Int32	fileSize = 0;
  Int8	fileName[256];
  Int8  itype[24];
  Uint32   baseAddress = 0, armboot;
  Uint32   blockSize, blockAddr;
  Int32 offset = -1;


  DEBUG_printString("Starting DA850/OMAP-L138 NOR Flash Writer.\n");

  /* read the chip type you are on. */
  if (davinci_get_part_no() == DA850_PART_NUM) {
    printf("DA850/OMAP-L138 part detected. ");
    if (*(unsigned int*)(CHIPREV_ID_BASE) & (1 << 4)) {
      armboot = 1;
      printf("Its an ARM boot device\n"
        "\tYou require two images to boot this device\n"
        "\t1) ARM UBL in AIS file format.\n"
        "\t2) U-Boot image in raw binary format\n");
    } else {
        printf("Its a DSP  boot device\n"
            "\tYou require three images to boot\n"
            "\t1) DSP UBL in AIS file format.\n"
            "\t2) ARM UBL in raw binary format.\n"
            "\t3) U-Boot image in raw binary format\n");
    }

    printf("To generate the AIS format file, you need to run"
        " the ARM/DSP .out (COFF) file generated from"
        " CCS build through the AISGen tool.\n");
  }

  // Initialize NOR Flash
  hNorInfo = NOR_open((Uint32)&NORStart, 2 /* 16 Bit */ );
  if (hNorInfo == NULL)
	{
    DEBUG_printString( "\tERROR: NOR Initialization failed.\r\n" );
    return E_FAIL;
  }

  /* Get NOR block size */
  NOR_getBlockInfo(hNorInfo, (Uint32)&NORStart, &blockSize, &blockAddr);

	if(armboot)
		printf("Enter the image type (one of \"armais\" \"uboot\" \"other\")\n");
	 else
		printf("Enter the image type (one of \"dspais\" \"armubl\" \"uboot\" \"other\")\n");
	scanf("%s", itype);

	if(!strcmp(itype, "dspais") || (armboot && !strcmp(itype, "armais")))
		offset = 0;
	else if(!armboot && !strcmp(itype, "armubl"))
		offset = blockSize;
	else if(!strcmp(itype, "uboot")) {
		offset = (armboot ? blockSize : 2 * blockSize);
	}

	// Read the file from host
	printf("Enter the File Name\n");
	scanf("%s", fileName);
	fflush(stdin);

	// Read the offset from user
	if(offset == -1) {
		printf("Enter the Offset in bytes (decimal)\n");
		scanf("%d", &offset);
		fflush(stdin);
	}

  // Set base address to start putting data at
  baseAddress = hNorInfo->flashBase + offset;

  // Open a file from the PC
  fPtr = fopen(fileName, "rb");
  if(fPtr == NULL)
  {
	DEBUG_printString("\tERROR: File ");
    DEBUG_printString(fileName);
    DEBUG_printString(" open failed.\r\n");
    return E_FAIL;
  }

    // Read file size
    fseek(fPtr,0,SEEK_END);
    fileSize = ftell(fPtr);

    // Setup pointer in RAM
    tmp = filePtr = (Uint8 *) UTIL_allocMem(fileSize);

    if(fileSize == 0)
    {
      DEBUG_printString("\tERROR: File read failed.. Closing program.\r\n");
      fclose (fPtr);
      return E_FAIL;
    }

    fseek(fPtr,0,SEEK_SET);

	if (!strcmp(itype, "uboot")) {
		norBoot = (NORWRITER_Boot*) filePtr;
		norBoot->magicNum = UBL_MAGIC_BIN_IMG;
		norBoot->entryPoint = 0xc1080000;
		norBoot->ldAddress = 0xc1080000;
		norBoot->appSize = fileSize;
		tmp += sizeof(NORWRITER_Boot);
	}

    if (fileSize != fread(tmp, 1, fileSize, fPtr))
    {
      DEBUG_printString("\tWARNING: File Size mismatch.\r\n");
    }

    fclose (fPtr);

	if (!strcmp(itype, "uboot")) {
		fileSize += sizeof(NORWRITER_Boot);
	}

    // Erasing the Flash
    if ( NOR_erase(hNorInfo, baseAddress, fileSize) != E_PASS )
    {
      DEBUG_printString("\tERROR: Erasing NOR failed.\r\n");
      return E_FAIL;
    }
	        
    // Write the actual application to the flash
    if (NOR_writeBytes( hNorInfo, baseAddress, fileSize, (Uint32)filePtr) != E_PASS)
    {
      DEBUG_printString("\tERROR: Writing NOR failed.\r\n");
      return E_FAIL;
    }

	return E_PASS;
}


/***********************************************************
* End file                                                 *
***********************************************************/

/* --------------------------------------------------------------------------
    HISTORY
        v1.00  -  DJA  -  06-Nov-2007
 	        Completion
 ----------------------------------------------------------------------------- */

