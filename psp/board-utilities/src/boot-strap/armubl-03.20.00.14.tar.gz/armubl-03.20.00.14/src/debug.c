/*
 * TI Booting and Flashing Utilities
 *
 * Debug utility functions that are mapped to a specific I/O device for this
 * particular project.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

// General type include
#include "tistdtypes.h"

// I/O module
#include "uart.h"

// This module's header file
#include "debug.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/


/************************************************************
* Local Variable Definitions                                *
\***********************************************************/


/************************************************************
* Global Variable Definitions
************************************************************/


/************************************************************
* Global Function Definitions                               *
************************************************************/
#if defined(DEVICE_UART0_FOR_DEBUG) || defined(DEVICE_UART1_FOR_DEBUG) || defined(DEVICE_UART2_FOR_DEBUG)
// Debug print function (could use stdio or maybe UART)
Uint32 DEBUG_printString(String s)
{
  return UART_sendString(s, FALSE);
}

Uint32 DEBUG_printHexInt(Uint32 i)
{
  UART_sendString("0x",FALSE);
  return UART_sendHexInt(i);
}

Uint32 DEBUG_readString(String s)
{
  return UART_recvString(s);
}

Uint32 DEBUG_readChar(Char *c)
{
  Uint32 len = 1;
  return UART_recvStringN(c,&len,FALSE);
}

#else
// No debug option
Uint32 DEBUG_printString(String s)
{
  return E_PASS;
}

Uint32 DEBUG_printHexInt(Uint32 i)
{
  return E_PASS;
}

Uint32 DEBUG_readString(String s)
{
  return E_PASS;
}

Uint32 DEBUG_readChar(Char *c)
{
  return E_PASS;
}
#endif
/************************************************************
* Local Function Definitions                                *
************************************************************/


/***********************************************************
* End file                                                 *
***********************************************************/



