/* --------------------------------------------------------------------------
  FILE      : sdmmc.c
  PROJECT   : TI Boot and Flash Utilities
  AUTHOR    : Daniel Allred
  DESC      : Generic SDMMC memory driver
-------------------------------------------------------------------------- */

// General type include
#include "tistdtypes.h"

// Device specific CSL
#include "device.h"

// Util functions
#include "util.h"

// The generic SD/MMC module driver 
#include "sdmmc.h"


/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/
static Uint8 Local_SDMMCInitCard(SDMMC_InfoHandle hSDMMCInfo, Uint32 *rca);

/************************************************************
* Local Variable Definitions                                *
************************************************************/


/************************************************************
* Global Variable Definitions                               *
************************************************************/

#ifdef USE_IN_ROM
SDMMC_InfoObj gSDMMCInfo;
#endif
// Default SPI Config strcuture
const SDMMC_ConfigObj DEFAULT_SDMMC_CONFIG = 
{
SDMMC_LITTLE_ENDIAN,
SDMMC_LITTLE_ENDIAN,
SDMMC_DAT3_EDGE_DETECT_DISABLE,
(Uint8)FALSE,
(Uint8)FALSE,
(Uint8)FALSE,
(Uint8)0,
SDMMC_MODE_NATIVE, /* No SPI */
(Uint8)FALSE, /* Valid Only in SPI mode */
(Uint8)FALSE, /* Valid Only in SPI mode */
SDMMC_4BIT_DATABUS,
(Uint16)0xFF,
0xFFFF,
SDMMC_FIFO_LEVEL_32BYTES
};

SDMMC_ConfigHandle const hDEFAULT_SDMMC_CONFIG = (SDMMC_ConfigHandle) &DEFAULT_SDMMC_CONFIG;
#define SDMMC_BLOCK_LENGTH     (512)

/************************************************************
* Global Function Definitions                               *
************************************************************/

// Initialze SDMMC interface and find the details of the SD/MMC card used
SDMMC_InfoHandle SDMMC_open(Uint32 sdmmcPeripheralNum, SDMMC_ConfigHandle hSDMMCCfg)
{
  SDMMC_InfoHandle hSDMMCInfo;
  Uint32 localDataBytesPerBlk = 0;
  Uint32 rca;

  // Set SDMMCInfo handle
#ifdef USE_IN_ROM
  hSDMMCInfo = (SDMMC_InfoHandle) &gSDMMCInfo;
#else
  hSDMMCInfo = (SDMMC_InfoHandle) UTIL_allocMem(sizeof(SDMMC_InfoObj));
#endif

  if (hSDMMCCfg == NULL)
  {
    hSDMMCInfo->hSDMMCCfg = hDEFAULT_SDMMC_CONFIG;
  }
  else
  {
    hSDMMCInfo->hSDMMCCfg = hSDMMCCfg;
  }
  hSDMMCInfo->dataBytesPerBlk = SDMMC_BLOCK_LENGTH;

  localDataBytesPerBlk = hSDMMCInfo->dataBytesPerBlk;
  hSDMMCInfo->dataBytesPerBlkPower2 = 0;
  while(localDataBytesPerBlk > 1)
  {
    localDataBytesPerBlk >>= 1;
	hSDMMCInfo->dataBytesPerBlkPower2++;
  }
  // Open SDMMC peripheral
  Local_SDMMCInitCard(hSDMMCInfo, &rca);  

  return hSDMMCInfo;
}

// Defining this macro for the build will cause write (flash) ability to be removed
// This can be used for using this driver as read-only for ROM code
#ifndef USE_IN_ROM    

// Global Erase NOR Flash
Uint32 SDMMC_globalErase(SDMMC_InfoHandle hSDMMCInfo)
{
  return E_PASS;
}

// NAND Flash erase block function
Uint32 SDMMC_eraseBytes(SDMMC_InfoHandle hSDMMCInfo, Uint32 startAddr, Uint32 byteCnt)
{  
  return E_PASS;
}
#endif

/************************************************************
* Local Function Definitions                                *
************************************************************/

void SDMMCClearResponse() {
  SDMMC->MMCRSP01 = 0x0;
  SDMMC->MMCRSP23 = 0x0;
  SDMMC->MMCRSP45 = 0x0;
  SDMMC->MMCRSP67 = 0x0;
  SDMMC->MMCCIDX &= 0xFFC0;

}

/**
    Send Command to MMC/ SD

    command  Command to be sent to MMC/ SD
    argument  Arguments to be sent with the command
    checkStatus  0: no status check, 1: status check
	statusBits  status bits to be checked in MMCST0 register, if 'checkStatus' = 1

    E_PASS, on completion
*/
Uint8 SDMMCSendCmd(Uint32 command, Uint32 argument, Bool checkStatus) {
  
	Uint32 statusRegBits=0x0;
	volatile Uint32 dummyread;

	// Dummy read
	dummyread = SDMMC->MMCST0;

   	/* Clear Response Registers*/
   	SDMMCClearResponse();


   	//Setup the Argument Register and send CMD */
   	SDMMC->MMCARGHL = argument;
   	SDMMC->MMCCMD   = command;
  
   	/*Delay loop allowing cards to respond */
	UTIL_waitLoop(1000);
        
   	if (checkStatus == 1) {
	   	/* Wait for RspDne; exit on RspTimeOut or RspCRCErr
		   bit 2 - RSPDNE
		   bit 3 - 7 Error/timeout */
	   	while((statusRegBits & (0x00FC)) == 0 )
	    {
	     statusRegBits = SDMMC->MMCST0;
	    }

	    return( ((statusRegBits & 0x4) == 0x4) ? E_PASS : E_DEVICE );
	}

	return E_PASS;
}


/**
    Get Response from MMC/SD controller and Clear Response

    SDMMCResponse Command Response is received in this parameter

    if success, \c E_PASS, else error code

*/
Uint8 SDMMCGetResponse(SDMMC_ResponseData* sdMmcResponse)
{
  sdMmcResponse->response[0] = (SDMMC->MMCRSP01 & 0xFFFF); 
  sdMmcResponse->response[1] = (SDMMC->MMCRSP01 & 0xFFFF0000) >> 16;
  sdMmcResponse->response[2] = (SDMMC->MMCRSP23 & 0xFFFF); 
  sdMmcResponse->response[3] = (SDMMC->MMCRSP23 & 0xFFFF0000) >> 16;
  sdMmcResponse->response[4] = (SDMMC->MMCRSP45 & 0xFFFF); 
  sdMmcResponse->response[5] = (SDMMC->MMCRSP45 & 0xFFFF0000) >> 16;
  sdMmcResponse->response[6] = (SDMMC->MMCRSP67 & 0xFFFF); 
  sdMmcResponse->response[7] = (SDMMC->MMCRSP67 & 0xFFFF0000) >> 16;
  sdMmcResponse->commandIdk  = (SDMMC->MMCCIDX  & 0x003F);
	
  SDMMCClearResponse();

  return E_PASS;
}

Uint32 SDMMCSendCmdOpCond(Uint32 in_volt_win, Uint32 in_timeout)
{
   Uint32 rtn;
   
   while (in_timeout > 0)
   {
      rtn = SDMMCSendCmd(SD_APP_OP_COND, in_volt_win, TRUE);
      if (rtn != E_PASS)
         return (rtn);
      
      if ((SDMMC->MMCRSP67 & 0x80000000))
         return (E_PASS);
      
      rtn = SDMMCSendCmd(SDMMC_APP_CMD, SDMMC_STUFF_BITS, TRUE);
      if (rtn != E_PASS)
         return (rtn);
      
      in_timeout--;
   }
   
   return (E_FAIL);
}

Uint32 SDMMCSetBusWidth(Uint32 rca, Uint32 in_bus_width)
{
   Uint32 rtn;
   Uint32 timeout;
   
   // verify input.
   if (1 == in_bus_width)
   {
      in_bus_width = 2;
   }
   else if (0 == in_bus_width)
   {
      in_bus_width = 1;
   }
   else
   {
      return (E_FAIL);
   }
   
   for (timeout = 0; timeout < SDMMC_OP_TIMEOUT; timeout++)
   {
      rtn = SDMMCSendCmd(SDMMC_APP_CMD, rca << 16, TRUE);
      if (rtn != E_PASS)
         return (rtn);

      rtn = SDMMCSendCmd(SD_SET_BUS_WIDTH, in_bus_width, TRUE);
      if (rtn == E_PASS)
         break;
   }

   // set width to 1, for a 4-bit data bus - sd card.
   if (E_PASS == rtn)
   {
      if (0 == in_bus_width)
      {
         SDMMC->MMCCTL &= 0xFFFB;
      }
      else
      {
         SDMMC->MMCCTL |= 0x0004;
      }
   }

   return (rtn);
}


/**
	MMC/SD interface selection, Controller and Card Initialization

*/
static Uint8 Local_SDMMCInitCard(SDMMC_InfoHandle hSDMMCInfo, Uint32 *rca) {
   volatile Uint32 rtn;
   SDMMC_ResponseData response[8];
   Uint32 temp;

   // place mmc/sd into reset.
   SDMMC->MMCCTL = 0x00000002 | 0x00000001;
   
   // enable the memory clock.
   SDMMC->MMCCLK = 0x01FF;
   UTIL_waitLoop(10000);
   
   SDMMC->MMCTOR = (Uint16)hSDMMCInfo->hSDMMCCfg->timeoutResponse;//0xFF;
   SDMMC->MMCTOD = (Uint16)hSDMMCInfo->hSDMMCCfg->timeoutRead;//0xFFFF;

   // release mmc/sd from reset.
   SDMMC->MMCCTL = 0;
   
   // configure the fifo to 64 byte level.
   SDMMC->MMCFIFOCTL |= 0x00000004;
   
   SDMMC->MMCNBLK = 1;
   SDMMC->MMCBLEN = SDMMC_BLOCK_LENGTH;

   // put cards in idle state.
   rtn = SDMMCSendCmd(0x00008000 | SDMMC_GO_IDLE_STATE, SDMMC_STUFF_BITS, TRUE);
   if (rtn != E_PASS)
      return (rtn);

   rtn = SDMMCSendCmd(SDMMC_HICAP_CMD, (0x100 | SD_HIGH_CAPACITY_ECHO_PATTERN), TRUE);

   temp = (SDMMC->MMCRSP67 & 0x000000FF);

   if(temp ==  SD_HIGH_CAPACITY_ECHO_PATTERN)
   {
      // add short delay and send voltage range.
      UTIL_waitLoop(100000);
      SDMMCSendCmd(SDMMC_APP_CMD, SDMMC_STUFF_BITS, TRUE);
      
      // TODO: add mmc identify card.
      rtn = SDMMCSendCmdOpCond(0x40000000 | SDMMC_VDD_27_36, SDMMC_OP_TIMEOUT);

      temp = (SDMMC->MMCRSP67 & 0xC0000000);

      /*
       * some cards which are not high-capacity, but entered
       * the loop, fail here
       */
      if (temp & 0x40000000)
         hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard = 1;
      else
         hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard = 0;
   }
   else
   {
      hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard = 0;

      // add short delay and send voltage range.
      UTIL_waitLoop(100000);
      SDMMCSendCmd(SDMMC_APP_CMD, SDMMC_STUFF_BITS, TRUE);
   
      // TODO: add mmc identify card.
      rtn = SDMMCSendCmdOpCond(SDMMC_VDD_27_36, SDMMC_OP_TIMEOUT);
   }
      
   // request all the cid info.
   rtn = SDMMCSendCmd(SDMMC_ALL_SEND_CID, SDMMC_STUFF_BITS, TRUE);
   SDMMCGetResponse(response);

   // ask for suggested relative address.
   rtn = SDMMCSendCmd(MMC_SET_RELATIVE_ADDR | MMCCMD_REG_PPLEN, SDMMC_STUFF_BITS, TRUE);
   if (rtn != E_PASS)
      return (rtn);
      
   *rca = SDMMC->MMCRSP67 >> 16;

   // select the card using the selected rca.
   rtn = SDMMCSendCmd(SDMMC_SELECT_CARD, *rca << 16, TRUE);
   if (rtn != E_PASS)
      return (rtn);
   
   // set bus width to 4-bit mode.
   rtn = SDMMCSetBusWidth(*rca, 1);
   if (rtn != E_PASS)
      return (rtn);

   // config the desired block length.
   rtn = SDMMCSendCmd(SDMMC_SET_BLOCKLEN, 512, FALSE);
   
   return (rtn);
}

/**
    Read N words from the MMC Controller Register

    data     -  Buffer for storing read data from the MMC
    numWords -  Number of words to be read from the MMC

*/
Uint8 SDMMCReadNWords(Uint32 *data, Uint32 numofBytes) 
{
  Uint16 i=0,j=0;
  Uint32 status;
  Uint32 fifoReadItrCount=0;          /* Word counter */
  fifoReadItrCount= numofBytes >> 5;

  for(i=0; i < fifoReadItrCount/2; i++)
  {			 	      
  	if(i != (fifoReadItrCount -1))
	{
	    
		// wait for DRRDY timeout
		do {
               status=SDMMC->MMCST0;
               if (status & 0xf8)
                   return (E_FAIL);
         } while(! (status & 0x0400) );	
	}
     
	for(j=0;j < 16; j++)
		*data++ = SDMMC->MMCDRR;
  }

  return ( E_PASS );
}

/**
    Send command to read a single block of data from the MMC/SD card

    cardAddr  Address of the location on the card to be read (should be a multiple of )
    dest  Buffer to read data into, from MMC/SD card
	blkLength  Size of the block in bytes, to be read from MMC/SD card

*/
Uint8 SDMMCSingleBlkRead( SDMMC_InfoHandle hSDMMCInfo, Uint32 cardMemAddr, Uint32 *dest, Uint32 blkLength ) 
{
   Uint32 rtn;
   Uint8 status;
   Uint32 timeOut;

   // reset fifo and config for receive.
   SDMMC->MMCFIFOCTL |= 0x00000001;
   UTIL_waitLoop(100);
   SDMMC->MMCFIFOCTL &= ~0x00000002;
   
   // send the single block read command.
   if (hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard)
      rtn = SDMMCSendCmd(0x12000 | SDMMC_READ_SINGLE_BLOCK, cardMemAddr >> hSDMMCInfo->dataBytesPerBlkPower2, FALSE);
   else
      rtn = SDMMCSendCmd(0x12000 | SDMMC_READ_SINGLE_BLOCK, cardMemAddr, FALSE);
   if (rtn != E_PASS)
      return (rtn);

  status=SDMMCReadNWords((Uint32*)dest, blkLength);
  if(status !=E_PASS)
	 return E_FAIL; 

  UTIL_waitLoop(100); 

  /*Delay needed for safety */
  timeOut = 3000;
  do {
	if(SDMMC->MMCST0 & SDMMC_STAT0_DATDNE) {
		return E_PASS;	
	}
	timeOut--;
	if( timeOut == 0 ) 
		return E_TIMEOUT;
  } while(1);
}
/**
    Send command to read multiple blocks of data from the MMC/SD card

    cardAddr  - Address of the location on the card to be read (should be a multiple of )
    dest      - Buffer to read data into, from MMC/SD card
	dataLength - Number of bytes to be read
*/
Uint8 SDMMCMultipleBlkRead( SDMMC_InfoHandle hSDMMCInfo, Uint32 cardMemAddr, Uint32 *dest, Uint32 dataLength) 
{
   Uint32 rtn, numBlks, status;
   Uint8 retVal;
   volatile Uint32 timeOut;

   retVal = E_PASS;

   numBlks = dataLength >> hSDMMCInfo->dataBytesPerBlkPower2;

   SDMMC->MMCBLEN |= hSDMMCInfo->dataBytesPerBlk;
   SDMMC->MMCNBLK =  numBlks;

   // reset fifo and config for receive.
   SDMMC->MMCFIFOCTL |= 0x00000001;
   UTIL_waitLoop(100);
   SDMMC->MMCFIFOCTL &= ~0x00000002;
   
   // send the Multiple block read command.
   if (hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard)
      rtn = SDMMCSendCmd(0x12000 | SDMMC_READ_MULTIPLE_BLOCK, cardMemAddr >> hSDMMCInfo->dataBytesPerBlkPower2, TRUE);
   else
      rtn = SDMMCSendCmd(0x12000 | SDMMC_READ_MULTIPLE_BLOCK, cardMemAddr, TRUE);

   if (rtn != E_PASS)
      return (rtn);
   
  status=SDMMCReadNWords((Uint32*)dest, dataLength);
  if(status !=E_PASS)
	 return E_FAIL; 

  /*Delay needed for safety */
  UTIL_waitLoop(10000); 
  timeOut = 50000;
  do {
	if(SDMMC->MMCST0 & SDMMC_STAT0_DATDNE) {
	    retVal = E_PASS;
		break;
	}
	timeOut--;
	if( timeOut == 0 ) {
	    retVal = E_TIMEOUT;
		break;
	}
  } while(1);

   /* Send the Stop Tx Command */
   status = SDMMCSendCmd(SDMMC_STOP_TRANSMISSION, cardMemAddr, FALSE);
      if(status != E_PASS)
         retVal = E_FAIL;

   return retVal;
}

/**
    \brief  Write N words to the MMC Controller Register

    \param  data  Buffer containing data to be written to the MMC
    \param  numWords  Number of words to be written to the MMC

    \return if success, \c E_PASS, else error code

*/
Uint8 SDMMCWriteNWords( SDMMC_InfoHandle hSDMMCInfo, Uint32 *data, Uint32 numofBytes,Uint32 cardMemAddr ) 
{
  register volatile Uint16 stat;
  Uint32 ii=0,jj=0,fifoDxrWrCnt=0;
  Uint32 fifoWriteItrCount=0;          /* Word counter */
  Uint8 status = E_PASS;
#if 0
  /* reset the FIFO  */
  //CSL_FINS(SDMMC->MMCFIFOCTL,SDMMC_MMCFIFOCTL_FIFORST,1);
  SDMMC->MMCFIFOCTL = (((SDMMC->MMCFIFOCTL) & ~DEVICE_SDMMC_MMCFIFOCTL_FIFORST_MASK) | 
  ((1 << DEVICE_SDMMC_MMCFIFOCTL_FIFORST_SHIFT) & DEVICE_SDMMC_MMCFIFOCTL_FIFORST_MASK));
	
  /* Set the Transfer direction from the FIFO as transmit*/
  //CSL_FINS(SDMMC->MMCFIFOCTL,SDMMC_MMCFIFOCTL_FIFODIR,1);
  SDMMC->MMCFIFOCTL = (((SDMMC->MMCFIFOCTL) & ~DEVICE_SDMMC_MMCFIFOCTL_FIFODIR_MASK) | 
  ((1 << DEVICE_SDMMC_MMCFIFOCTL_FIFODIR_SHIFT) & DEVICE_SDMMC_MMCFIFOCTL_FIFODIR_MASK));
#endif
    /* reset the FIFO  */
  SDMMC->MMCFIFOCTL |= 0x1;

  /* Set the Transfer direction from the FIFO as receive*/
  SDMMC->MMCFIFOCTL |= 0x0002;

  /*Set the FIFO level 32 bytes (256 bit) always - Already done in Init TODO (remove?)*/
  SDMMC->MMCFIFOCTL |= 0x0004;

  fifoWriteItrCount=numofBytes >> 5;
  fifoDxrWrCnt=8;
     
  for(ii=0; ii < fifoWriteItrCount;ii++)
  {	
  	if(ii==0)
	{
		if(numofBytes == hSDMMCInfo->dataBytesPerBlk)
	        status = SDMMCSendCmd(0x2800 | SDMMC_WRITE_BLOCK, cardMemAddr,FALSE);
	    else
	        status = SDMMCSendCmd(0x2880 | SDMMC_WRITE_MULTIPLE_BLOCK, cardMemAddr, FALSE);
	}
  
  	for(jj=0;jj < fifoDxrWrCnt; jj++)
  		SDMMC->MMCDXR= (Uint32)*data++;

	   
  	if(ii != (fifoWriteItrCount -1))
  		while(!((SDMMC->MMCST0 & DEVICE_SDMMC_MMCST0_DXRDY_MASK) >> DEVICE_SDMMC_MMCST0_DXRDY_SHIFT));
  }	      		         		          		         		         
	     		        
  return (E_PASS);
}


Uint8 SDMMCSingleBlkWrite( SDMMC_InfoHandle hSDMMCInfo, Uint32 cardMemAddr, Uint32 *src, Uint32 blkLength)
{
  Uint8 status = E_PASS;

  SDMMC->MMCBLEN |= (Uint16)(hSDMMCInfo->dataBytesPerBlk&0xFFF);
  SDMMC->MMCNBLK =  1;
    
  status = SDMMCSendCmd(SDMMC_SET_BLOCKLEN, hSDMMCInfo->dataBytesPerBlk, FALSE);
  if(status != E_PASS)
  	return	E_FAIL;             
 
  if(status == E_PASS) 
  {
    if(hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard)
	{
  	  /* Write Data, every time MMCDXR Reg full */
	  status = SDMMCWriteNWords(hSDMMCInfo,(Uint32*)src, hSDMMCInfo->dataBytesPerBlk,cardMemAddr >> hSDMMCInfo->dataBytesPerBlkPower2);
	}
	else
	{
  	  /* Write Data, every time MMCDXR Reg full */
	  status = SDMMCWriteNWords(hSDMMCInfo, (Uint32*)src, hSDMMCInfo->dataBytesPerBlk,cardMemAddr);
	}
		   
	/*Delay Required*/
	//UTIL_waitLoop(100);
		 
    if(status == E_PASS)
    {
	do {
	  	if(SDMMC->MMCST0 & SDMMC_STAT0_DATDNE)
			return E_PASS;
	} while(1);       
		   	     
    }else
		 return E_FAIL;
  }	
  return E_PASS;
}

Uint8 SDMMCMultipleBlkWrite( SDMMC_InfoHandle hSDMMCInfo, Uint32 cardMemAddr, Uint32 *src, Uint32 datalength) 
{
	Uint8 status;
	Uint32 numBlks;
      
   /*Clear all Response Registers */  
   SDMMCClearResponse();
     
   /* To find out number of BLOCKS to be written in terms of 512 bytes */
   numBlks = datalength >> hSDMMCInfo->dataBytesPerBlkPower2;

   if(numBlks* hSDMMCInfo->dataBytesPerBlk < datalength)
     numBlks++;
    
   SDMMC->MMCBLEN |= hSDMMCInfo->dataBytesPerBlk;
   SDMMC->MMCNBLK =  numBlks;

   /* Send the BLOCK LEN command to the card , it is an optional one*/
   status = SDMMCSendCmd(SDMMC_SET_BLOCKLEN, hSDMMCInfo->dataBytesPerBlk, FALSE);
   if(status!=E_PASS)
	   return E_FAIL;  
    if(hSDMMCInfo->mmcSdCSDRegInfo.sdHighCapacityCard)
	{             		
      /* Read Data, every time Data Rd Reg full, till all words read */
      status = SDMMCWriteNWords(hSDMMCInfo, (Uint32*)src,datalength,cardMemAddr >> hSDMMCInfo->dataBytesPerBlkPower2);
	}
    else
	{             		
      /* Read Data, every time Data Rd Reg full, till all words read */
      status = SDMMCWriteNWords(hSDMMCInfo, (Uint32*)src,datalength,cardMemAddr);
	}

   /*Delay required */
   UTIL_waitLoop(100);
			  
   if(status != E_PASS)
	return E_FAIL;

   /* Check for SDMMC_DATDNE signal */ 
   /* No timeout in QT mode */
   do {
   	if(SDMMC->MMCST0 & SDMMC_STAT0_DATDNE) {
 		SDMMCSendCmd(0xA180 | SDMMC_STOP_TRANSMISSION, SDMMC_STUFF_BITS, FALSE);
		    return E_PASS;
	}
   } while(1);       
}


/***********************************************************
* End file                                                 *
***********************************************************/

