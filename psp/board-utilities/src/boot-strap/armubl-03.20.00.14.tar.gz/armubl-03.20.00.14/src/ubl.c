/*
 * TI Booting and Flashing Utilities
 *
 * The main project file for the user boot loader
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

// General type include
#include "tistdtypes.h"

// This module's header file
#include "ubl.h"

// Device specific CSL
#include "device.h"

// Misc. utility function include
#include "util.h"

// Project specific debug functionality
#include "debug.h"
#include "uartboot.h"


#ifdef UBL_NOR
// NOR driver include
#include "nor.h"
#include "norboot.h"
#endif

#ifdef UBL_NAND
// NAND driver include
#include "nand.h"
#include "nandboot.h"
#endif

#ifdef UBL_SPI
// SPI driver include
#include "spi.h"
#endif

/************************************************************
* Explicit External Declarations                            *
************************************************************/


/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/

static Uint32 LOCAL_boot(void);
static void (*APPEntry)(void);


/************************************************************
* Local Variable Definitions                                *
************************************************************/

/************************************************************
* Global Variable Definitions                               *
************************************************************/

extern Uint32 gEntryPoint;

extern DEVICE_OperatingPoint gDeviceOpPoint;
/************************************************************
* Global Function Definitions                               *
************************************************************/

// Main entry point
void main(void)
{

  // First thing, put DSP in reset
  DEVICE_disable_DSP();

  // Call to real boot function code
  LOCAL_boot();

  // Jump to entry point
  DEBUG1_printString("\r\nJumping to entry point at ");
  DEBUG1_printHexInt(gEntryPoint);
  DEBUG1_printString(".\r\n");
  APPEntry = (void (*)(void)) gEntryPoint;
  (*APPEntry)();

}


/************************************************************
* Local Function Definitions                                *
************************************************************/

static Uint32 LOCAL_boot(void)
{
  volatile DEVICE_BootMode bootMode;

  // Read boot mode
  bootMode = DEVICE_bootMode();

  // OMAP-L138 doesn't support SD/MMC boot, fake it
#ifdef UBL_SD_MMC
  bootMode = DEVICE_BOOTMODE_SD_MMC;
#endif

  if (bootMode == DEVICE_BOOTMODE_UART)
  {
    // Wait until the RBL is done using the UART.
    while((UART0->LSR & 0x40) == 0 );
  }

  // Platform Initialization
  if ( DEVICE_init(bootMode) != E_PASS )
  {
    DEBUG_printString("Chip initialization failed!\r\n");
    asm(" MOV PC, #0");
  }
  else
  {
    DEBUG1_printString("Chip initialization passed!\r\n");
  }

  // Set RAM pointer to beginning of RAM space
  UTIL_setCurrMemPtr((void*)0);

  // Send some information to host
  DEBUG_printString("\r\nBooting with TI UBL");

  switch(gDeviceOpPoint.opp)
  {
      case DEVICE_OPP_1P2V_300MHZ:
        DEBUG0_printString("\r\nDevice OPP (300MHz, 1.2V)");
      break;
      case DEVICE_OPP_1P2V_372MHZ:
        DEBUG0_printString("\r\nDevice OPP (372MHz, 1.2V)");
      break;
      case DEVICE_OPP_1P2V_408MHZ:
        DEBUG0_printString("\r\nDevice OPP (408MHz, 1.2V)");
      break;
      case DEVICE_OPP_1P3V_408MHZ:
        DEBUG0_printString("\r\nDevice OPP (408MHz, 1.3V)");
      break;
      case DEVICE_OPP_1P3V_456MHZ:
        DEBUG0_printString("\r\nDevice OPP (456MHz, 1.3V)");
      break;
      default:
        DEBUG0_printString("\r\nInvalid Operating Point");
        return E_FAIL;
  }

  DEBUG1_printString("\r\nBooting Catalog Boot Loader\r\nBootMode = ");

  // Select Boot Mode
  switch(bootMode)
  {
#ifdef UBL_NAND
    case DEVICE_BOOTMODE_NAND_EMIFA_8BIT:
    {
      //Report Bootmode to host
      DEBUG1_printString("NAND\r\n");

      // Copy binary image application from NAND to RAM
      if (NANDBOOT_copy() != E_PASS)
      {
        DEBUG_printString("NAND Boot failed.\r\n");
        goto UARTBOOT;
      }
      break;
    }
#endif
#ifdef UBL_NOR
    case DEVICE_BOOTMODE_NOR_EMIFA:
    {
      //Report Bootmode to host
      DEBUG1_printString("NOR \r\n");

      // Copy binary application image from NOR to RAM
      if (NORBOOT_copy() != E_PASS)
      {
        DEBUG_printString("NOR Boot failed.\r\n");
        goto UARTBOOT;
      }
      break;
    }
#endif
#ifdef UBL_SD_MMC
    case DEVICE_BOOTMODE_SD_MMC:
    {
      //Report Bootmode to host
      DEBUG1_printString("SD/MMC \r\n");

      // Copy binary of application image from SD/MMC card to RAM
      if (SDMMCBOOT_copy() != E_PASS)
      {
        DEBUG_printString("SD/MMC Boot failed.\r\n");
        DEVICE_SPI1Init();
        DEBUG1_printString("Trying SPI 1 Flash \r\n");
        if (SPIBOOT_copy(1) != E_PASS)
        {
          DEBUG_printString("SPI 1 Boot failed.\r\n");
          goto UARTBOOT;
        }
      }
      break;
    }
#endif
#ifdef UBL_SPI
    case DEVICE_BOOTMODE_SPI0_FLASH:
    {
      //Report Bootmode to host
      DEBUG1_printString("SPI 0 Flash \r\n");

      // Copy binary of application image from SD/MMC card to RAM
      if (SPIBOOT_copy(0) != E_PASS)
      {
        DEBUG_printString("SPI Boot failed.\r\n");
        goto UARTBOOT;
      }
      break;
    }

    case DEVICE_BOOTMODE_SPI1_FLASH:
    {
      //Report Bootmode to host
      DEBUG1_printString("SPI 1 Flash \r\n");

      // Copy binary of application image from SD/MMC card to RAM
      if (SPIBOOT_copy(1) != E_PASS)
      {
        DEBUG_printString("SPI 1 Boot failed.\r\n");
        goto UARTBOOT;
      }
      break;
    }
#endif
    case DEVICE_BOOTMODE_UART:
    {
      //Report Bootmode to host
      DEBUG_printString("UART\r\n");
    }
    default:
    {
UARTBOOT:  UARTBOOT_copy();
      break;
    }
  }

  DEBUG1_printString("   DONE");

  UTIL_waitLoop(10000);

  DEVICE_TIMER0Stop();

  return E_PASS;
}


/************************************************************
* End file                                                  *
************************************************************/
