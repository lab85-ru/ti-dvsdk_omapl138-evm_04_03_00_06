/*
 * TI Booting and Flashing Utilities
 *
 * Module to boot the from a NAND flash device by finding the application
 * (usually U-boot) and loading it to RAM.
 *
 * Copyright (C) 2009 Texas Instruments Incorporated - http://www.ti.com/
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as 
 * published by the Free Software Foundation version 2.
 *
 * This program is distributed "as is" WITHOUT ANY WARRANTY of any
 * kind, whether express or implied; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

/* --------------------------------------------------------------------------
  AUTHOR      : Daniel Allred
 --------------------------------------------------------------------------- */

#ifdef UBL_SPI

// General type include
#include "tistdtypes.h"

// Device specific CSL
#include "device.h"

// Debug I/O module
#include "debug.h"

// Misc utility module
#include "util.h"

// Main UBL module
#include "ubl.h"

// SPI driver functions
#include "spi.h"
#include "spi_mem.h"

// This module's header file
#include "spiboot.h"

/************************************************************
* Explicit External Declarations                            *
************************************************************/

extern __FAR__ Uint32 DDRStart;
extern __FAR__ Uint32 DDRSize;

// Entrypoint for application we are decoding out of flash
Uint32 gEntryPoint;

/************************************************************
* Local Macro Declarations                                  *
************************************************************/


/************************************************************
* Local Typedef Declarations                                *
************************************************************/


/************************************************************
* Local Function Declarations                               *
************************************************************/


/************************************************************
* Local Variable Definitions                                *
************************************************************/


/************************************************************
* Global Variable Definitions                               *
************************************************************/

// structure for holding details about UBL stored in SPI
volatile SPIBOOT_HeaderObj  gSpiBoot;

/************************************************************
* Global Function Definitions                               *
************************************************************/

// Function to find out where the application is and copy to RAM
Uint32 SPIBOOT_copy(Uint32 spiInstanceNum)
{
  SPI_MemInfoHandle hSPIMemInfo;
  SPIBOOT_HeaderObj	header;
#ifdef CONFIG_MACH_DAVINCI_DA850_EVM
  Uint32 offset = 128*1024;
#elif CONFIG_MACH_DAVINCI_DA830_EVM
  Uint32 offset = 32*1024;
#endif


  DEBUG1_printString("Starting SPI Copy...\r\n");
 
  hSPIMemInfo = SPI_MEM_open(spiInstanceNum);

  if (hSPIMemInfo == NULL)
    return E_FAIL;

  /* read the chip type you are on. */
  if(DEVICE_isDSPBoot() == FALSE)
#ifdef CONFIG_MACH_DAVINCI_DA850_EVM
	offset = 64*1024;
#elif CONFIG_MACH_DAVINCI_DA830_EVM
	offset = 24*1024;
#endif
 
  // Assume U-Boot is at address 64K from start of SPI device (Block 0 has 
  // this UBL)
  SPI_MEM_readBytes(hSPIMemInfo, offset, sizeof(header), (Uint8*) &header);

  DEBUG1_printString("\r\nUBOOT header : (magicnumber, entry, appsize , ldAddress) - (");
  DEBUG1_printHexInt(header.magicNum);
  DEBUG1_printString(" ,");
  DEBUG1_printHexInt(header.entryPoint);
  DEBUG1_printString(" ,");
  DEBUG1_printHexInt(header.appSize);
  DEBUG1_printString(" ,");
  DEBUG1_printHexInt(header.ldAddress);
  DEBUG1_printString(" )");

  SPI_MEM_readBytes(hSPIMemInfo, offset + sizeof(header), header.appSize, (Uint8*) header.ldAddress);

  gEntryPoint = header.entryPoint;

  // Since our entry point is set, just return success
  return E_PASS;
}

/************************************************************
* Local Function Definitions                                *
************************************************************/


/***********************************************************
* End file                                                 *
***********************************************************/
#endif  // #ifdef UBL_SPI
